package seliniumlogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Automation {
	 public static void main(String[] args)
	    {
	       WebDriver driver = null;

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\gouth\\OneDrive\\Documents\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	        
	        driver.get("https://amazon.in/ap/signin?openid.pape.max_auth_age=0&openid return to=https://www.amazon.in/?ref_=nav_ya_signin&openid.identity=http:/1MX0%3D");
	        
	        driver.manage().window().maximize();
	        
	        driver.findElement(By.id("email"))
	        .sendKeys("Goutham@gmail.com");
	        
	        driver.findElement(By.id("pass"))
	        .sendKeys("Goutham@Reddy");
	        
	        driver.findElement(By.id("loginbutton"))
            .click();
	        
	    }
}
