package seliniumlogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Registration_Automation {
	
    public static void main(String[] args)
    {
        WebDriver driver = null;

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\gouth\\OneDrive\\Documents\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
        
        driver.get("https://amazon.in/ap/signin?openid.pape.max_auth_age=0&openid return to=https://www.amazon.in/?ref_=nav_ya_signin&openid.identity=http:/..._physical_ms%3D1007765%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=EAIaIQobChMIgKXQyLa3-gIVRSUrCh0rwQpyEAAYASAAEgI41vD_BwE");
        
        driver.manage().window().maximize();
        
        driver.findElement(By.name("yourname"))
        .sendKeys("Goutham");
        
      
        driver.findElement(By.name("reg_email__"))
            .sendKeys("Goutham@gmail.com");
        
        driver.findElement(By.name("reg_email_confirmation__"))
        .sendKeys("Goutham@gmail.com");
        
        driver.findElement(By.id("password_step_input"))
        .sendKeys("Goutham@Reddy");
        
        
        driver.findElement(By.className("_8esa"))
        .click();
  
        driver.findElement(By.name("websubmit"))
            .click();
    }
}
