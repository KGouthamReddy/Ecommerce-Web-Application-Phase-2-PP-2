export interface PostData {
    title: string;
    content: string;
    id: number;
  }