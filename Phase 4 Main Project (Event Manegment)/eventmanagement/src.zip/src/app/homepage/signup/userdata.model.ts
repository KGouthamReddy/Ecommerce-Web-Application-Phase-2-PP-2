export interface UserData {
    email: string;
    name: string;
    passward: string;
    id: number;
  }